<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta neme="viewport" content="width=device-width, initial-scale-1">
    <title>Student Admission form with PDF Previewable...</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qx5J10vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>

</body>
</html>
